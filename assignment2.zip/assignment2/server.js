//Loading modules
const http = require('http');
const pug = require("pug");
const fs = require("fs");

const { stringify } = require('querystring');
const { send } = require('process');
const { totalmem } = require('os');
const { moveMessagePortToContext } = require('worker_threads');

//pug render functions
const renderHome = pug.compileFile('views/home.pug'); 
const renderOrder = pug.compileFile('views/order.pug');
const renderStats = pug.compileFile('views/stats.pug'); 

//global variables
let orders = {};
let orderID = 0;

//creating server
const server = http.createServer((req, res) => {
    console.log('${req.method} for ${req.url}');

    if(req.method === "GET"){
        if(req.url === "/" || req.url === "/home"){
            res.setHeader("Content-Type", "text/html");
            sendResponse(res, 200, renderHome());
        }
        else if (req.url === "/order"){
            res.setHeader("Content-Type", "text/html");
            sendResponse(res, 200, renderOrder());
        }
        else if (req.url === "/stats"){
            res.setHeader("Content-Type", "text/html");
            sendResponse(res, 200, renderStats({orders}));
        }
        else if (req.url === "/orders"){
            let categories = [];
            for (const id in orders) categories.push(orders[id],category);
            res.setHeader("Content-Type", "application/json");
            sendResponse(res, 200, JSON,stringify(categories));
        }
        else if (req.url.startsWith("/orders/")){
            let id = req.url.slice("/orders/".length);
            if (id === "" || isNaN(id)) return sendResponse(res, 400, "Order id is not specified");
            res.setHeader("Content-Type", "application/json");
            sendResponse(res, 200, JSON.stringify(orders[id]));
        }
        else sendResponse(res, 404,)
    }
})

//reading files
fs.readdir("./restaurants", (err,files) =>{
    if (err) return console.log(err);
    console.log(files);
    for(let i=0; i < files.length; i++){
        let order = require("./restaurants/" + files[i]);
        console.log(order);
        order.average = {};
        order.received = 0;
        mostpopular = {};
        orders[orderID++] = order;
    }
    initAttempts();
    server.listen(3000);
    console.log('Server running at https://127.0.0.1:3000/');
});

//ajax get request fuction
function getRestaurantCategories(){
    let req = new XMLHttpRequest();
    req.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200){
            categories = JSON.parse(this.responseText);
            categoriesToHTML();
            getOrder(0);
        }
    }
    req.open("GET", 'http://localhost:3000/orders');
    req.setRequestHeader("Accept", "application/JSON");
    req.send();
}

function getOrder(id){
    let req = new XMLHttpRequest();
    req.onreadystatechange = function(){
    if(this.readyState==4 && this.status==200){
        const order = JSON.parse(this.responseText)
        orderToHTML(order);
        currentOrderID = categories.indexOf(order.category);
    }
    req.open("GET", 'http://localhost:3000/orders/${id}');
    req.setRequestHeader("Accept", "application/json");
    req.send();
}}

function postOrder(info){
    let req = new XMLHttpRequest();
    req.onreadystatechange = function(){
    if(this.readyState==4 && this.status==201){
        const order = JSON.parse(this.responseText)
        console.log(response);
        alert('Order has been received!');
        location.reload();
    }
    req.open("POST", "/summary");
    req.setRequestHeader("Content-Type", "application/json");
    req.send(JSON.stringify(info));
}}
