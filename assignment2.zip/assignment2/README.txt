To run the server, you will need to run "npm install"

This will look at the dependencies, in this case "pug":3.0.2 

It will automatically install all the correct versions and dependencies without the user 
having to install them 1 by 1 